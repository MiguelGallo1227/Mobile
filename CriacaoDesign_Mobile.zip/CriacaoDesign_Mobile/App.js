import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";

// Importa telas
import CriacaoInterface from "./screens/CriacaoInterface";
import EstruturaLayout from "./screens/EstruturaLayout";
import TiposLayout from "./screens/TiposLayout";
import GerenciadorLayout from "./screens/GerenciadorLayout";
import ComponentesTela from "./screens/ComponentesTela";
import DialogoModal from "./screens/DialogoModal";
import BarraAcao from "./screens/BarraAcao";
import ControleElementos from "./screens/ControleElementos";
import TratamentoExcecoes from "./screens/TratamentoExcecoes";
import ManipulacaoListas from "./screens/ManipulaçãoListas";
import EntradaSaida from "./screens/EntradaSaida";

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="2. Criação de Interface">
        <Drawer.Screen
          name="2. Criação de Interface"
          component={CriacaoInterface}
        />
        <Drawer.Screen name="2.1.1 Estrutura" component={EstruturaLayout} />
        <Drawer.Screen name="2.1.2 Tipos" component={TiposLayout} />
        <Drawer.Screen name="2.1.3 Gerenciador" component={GerenciadorLayout} />
        <Drawer.Screen name="2.1.4 Componentes" component={ComponentesTela} />
        <Drawer.Screen name="2.1.5 Dialogo" component={DialogoModal} />
        <Drawer.Screen name="2.1.6 BarraAcao" component={BarraAcao} />
        <Drawer.Screen name="2.1.7 ControleElementos" component={ControleElementos} />
        <Drawer.Screen name="2.1.8 TratamentoExcecoes" component={TratamentoExcecoes} />
        <Drawer.Screen name="2.1.9 ManipulçaoListas" component={ManipulacaoListas} />
        <Drawer.Screen name="2.2.1 EntradaSaida" component={EntradaSaida} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
