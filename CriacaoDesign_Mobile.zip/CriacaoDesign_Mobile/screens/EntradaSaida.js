import React, { useState } from 'react';
import { View, Text, StyleSheet, Button, TextInput } from 'react-native';

export default function EntradaSaidaSimples() {
  
  const [textoEntrada, setTextoEntrada] = useState('');
  

  const [textoSaida, setTextoSaida] = useState('');

 
  const handleConverterTexto = () => {
    if (textoEntrada) { 
        setTextoSaida(textoEntrada.toUpperCase());
    }
  };

  const limparCampos = () => {
    setTextoEntrada('');
    setTextoSaida('');
  };

  return (
    <View style={styles.container}>
      {}
      <TextInput
        style={styles.input}
        placeholder="Digite algo aqui"
        value={textoEntrada}
        onChangeText={setTextoEntrada}
      />

      {}
      <View style={styles.buttonsContainer}>
        {}
        <View style={styles.buttonWrapper}>
          <Button 
            title="Converter" 
            onPress={handleConverterTexto} 
          />
        </View>
        <View style={styles.buttonWrapper}>
          <Button 
            title="Limpar" 
            onPress={limparCampos} 
            color="#c74c3c" 
          />
        </View>
      </View>

      {}
      {textoSaida ? <Text style={styles.resultado}>{textoSaida}</Text> : null}
    </View>
  );
}


const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    padding: 20 
  },
  input: { 
    borderWidth: 1, 
    borderColor: '#ccc', 
    padding: 10, 
    marginBottom: 20, 
    width: '80%',
    fontSize: 16,
  },
  buttonsContainer: {
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    width: '80%',
  },
  buttonWrapper: {
    width: '48%', 
  },
  resultado: {
    marginTop: 20,
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
